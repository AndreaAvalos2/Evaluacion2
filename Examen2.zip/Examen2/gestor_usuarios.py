import pymongo

# Clase GestorUsuarios
class GestorUsuarios:
    def __init__(self, host=None, user="", password="", port="27017", mongo_uri=None):
        self.MONGO_USER = user
        self.MONGO_PASSWORD = password
        self.MONGO_HOST = host if host else "localhost"
        self.MONGO_PORT = port
        self.MONGO_URI = mongo_uri
        self.MONGO_CLIENT = None

    def conectar_mongodb(self):
        try:
            if self.MONGO_HOST == 'localhost':
                self.MONGO_URI = f"mongodb://{self.MONGO_HOST}:{self.MONGO_PORT}/"
            else:
                self.MONGO_URI = f"mongodb+srv://{self.MONGO_USER}:{self.MONGO_PASSWORD}@cluster.mongodb.net/?retryWrites=true&w=majority"
            self.MONGO_CLIENT = pymongo.MongoClient(self.MONGO_URI)
        except pymongo.errors.ServerSelectionTimeoutError as error_tiempo:
            print("Error de conexión:", error_tiempo)

    def cerrar_conexion_mongodb(self):
        if self.MONGO_CLIENT:
            self.MONGO_CLIENT.close()

    def obtener_usuarios(self, db='gestion_usuarios2', coleccion='usuarios'):
        self.conectar_mongodb()
        usuarios = self.MONGO_CLIENT[db][coleccion].find()
        return usuarios  # No cerramos la conexión aquí


# Clase Usuario
class Usuario:
    def __init__(self, usuario, rol, grupo, permisos):
        self.usuario = usuario
        self.rol = rol
        self.grupo = grupo
        self.__USER = {
            'usuario': usuario,
            'rol': rol,
            'grupo': grupo,
            'permisos': permisos
        }

    def tiene_permiso(self, permiso):
        return permiso in self.__USER['permisos']

    def get_permisos(self):
        return self.__USER['permisos']  # Método para acceder a los permisos


# Decorador para verificar permisos
def decorador_ver_pedidos(func):
    def wrapper(usuario, *args, **kwargs):
        if usuario.tiene_permiso('Ver-Pedidos'):
            print(f"{usuario.usuario} tiene permiso para ver pedidos.")
            return func(usuario, *args, **kwargs)  # Llama a la función si tiene permiso
        else:
            print(f"Permiso denegado para '{usuario.usuario}': no tiene el permiso 'Ver-Pedidos'.")
    return wrapper


# Ejemplo de uso
gestor = GestorUsuarios()

# Obtener usuarios desde la base de datos
usuarios_db = gestor.obtener_usuarios()

# Crear usuarios a partir de la información de la base de datos
usuarios = []
for usuario_db in usuarios_db:
    nombre = usuario_db['nombre']
    permisos = usuario_db.get('permisos', [])  # Usar get para evitar KeyError
    grupo = usuario_db.get('grupo', 'Desconocido')  # Asignar grupo por defecto

    usuario = Usuario(nombre, nombre, grupo, permisos)
    usuarios.append(usuario)

# Crear usuarios y asignarles permisos específicos
cliente = Usuario('Juan', 'Clientes', 'Cliente', ['Ver-Pedidos'])
soporte_cliente = Usuario('luis', 'Soporte Cliente', 'Soporte', ['Ver-Pedidos'])
administrador_producto = Usuario('Maria', 'Administrador Producto', 'Administración', ['Administrar-Productos'])
administrador_pedido = Usuario('Diego', 'Administrador Pedido', 'Administración', ['Administrar-Pedidos', 'Ver-Pedidos'])

# Agregar nuevos usuarios a la lista
usuarios.extend([cliente, soporte_cliente, administrador_producto, administrador_pedido])

# Imprime los permisos de todos los usuarios para verificar
for usuario in usuarios:
    print(f"Permisos de {usuario.usuario}: {usuario.get_permisos()}")  # Imprime permisos de cada usuario

# Función decorada para ver pedidos
@decorador_ver_pedidos
def ver_pedidos(usuario):
    print(f"Mostrando pedidos para {usuario.usuario}...")

# Ejecutar pruebas para cada usuario
for usuario in usuarios:
    print(f"\nIntentando ver pedidos para: {usuario.usuario}")
    ver_pedidos(usuario)

# Cerrar conexión a la base de datos al finalizar
gestor.cerrar_conexion_mongodb()
